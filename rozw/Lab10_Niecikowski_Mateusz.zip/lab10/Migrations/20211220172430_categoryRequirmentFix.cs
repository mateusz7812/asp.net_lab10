﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace lab10.Migrations
{
    public partial class categoryRequirmentFix : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
